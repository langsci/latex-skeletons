#!/bin/sh

for f in *blx.aux; do
echo ====================================================================
bibtex $f
done