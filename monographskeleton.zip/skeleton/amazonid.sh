#!/usr/bin/sh

ID=$1
echo https://www.amazon.de/dp/$ID?tag=wwwlangscipre-21
echo https://www.amazon.co.uk/dp/$ID?tag=wwwlangscip03-21
echo https://www.amazon.com/dp/$ID?tag=wwwlangscipre-20
