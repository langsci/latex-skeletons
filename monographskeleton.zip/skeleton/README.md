# Voice syncretism % \subtitle{Add subtitle here if it exists}
## Publication Info
- Authors: Nicklas N. Bahrt
- Publication Date: not yet published
- Series: rcg
## Description
[Book page on langsci-press.org](http://langsci-press.org/catalog/book/
## License
Copyright: (c) 2017, the authors.
All data, code and documentation in this repository is published under the [Creative Commons Attribution 4.0 Licence](http://creativecommons.org/licenses/by/4.0/) (CC BY 4.0).
